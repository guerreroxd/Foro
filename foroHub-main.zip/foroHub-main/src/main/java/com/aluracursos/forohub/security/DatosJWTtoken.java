package com.aluracursos.forohub.security;

public record DatosJWTtoken(String jwtToken , String nombre) {

}
