package com.aluracursos.forohub.security;

public record DatosAutenticacionUsuario(String correoElectronico, String password) {

}
