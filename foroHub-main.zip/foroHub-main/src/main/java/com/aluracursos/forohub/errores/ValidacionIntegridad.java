package com.aluracursos.forohub.errores;

public class ValidacionIntegridad extends RuntimeException {
    public ValidacionIntegridad(String s) {

        super(s);
    }
}

