package com.aluracursos.forohub.DTO;

public record DatosJWTtoken(String jwtToken, String nombreUsuario) {

}
